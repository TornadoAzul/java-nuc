package misdatos;

public class tarea_1_2 {
    public static void main(String[] args) {
        String nombre = "Juan Perez";
        String telefono = "555-1234";
        String correo = "juan.perez@example.com";
        
        System.out.println("Nombre: " + nombre);
        System.out.println("Teléfono: " + telefono);
        System.out.println("Correo electrónico: " + correo);
    }
}

// Emmanuel Alicea Rodríguez
// Tarea 1.2 PROG 3375